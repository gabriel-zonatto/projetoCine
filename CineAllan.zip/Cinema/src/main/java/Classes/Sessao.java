package Classes;

public class Sessao{


}